package sudoku.level;

public class Easy extends Level {
    public Easy() {
        super(40);
    }

    @Override
    public String toString() {
        return "Easy";
    }
}
