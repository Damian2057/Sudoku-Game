package sudoku.level;

public class Hard extends Level {
    public Hard() {
        super(55);
    }

    @Override
    public String toString() {
        return "Hard";
    }
}
