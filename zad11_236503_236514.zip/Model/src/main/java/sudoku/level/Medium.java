package sudoku.level;

public class Medium extends Level {
    public Medium() {
        super(50);
    }

    @Override
    public String toString() {
        return "Medium";
    }
}
