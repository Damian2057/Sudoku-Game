package sudoku.level;

public class VeryEasy extends Level {
    public VeryEasy() {
        super(1);
    }

    @Override
    public String toString() {
        return "VeryEasy";
    }
}
