package sudoku.exceptions;

public class LevelLogicalException extends SudokuBoardException {
    public LevelLogicalException() {
        super("logicallyLevel");
    }
}
