package sudoku;

public class SudokuBoardMultiplication {

    public SudokuBoardMultiplication() {

    }

    public SudokuBoard createSudoku(SudokuBoard sb) {
        return sb.clone();
    }
}
