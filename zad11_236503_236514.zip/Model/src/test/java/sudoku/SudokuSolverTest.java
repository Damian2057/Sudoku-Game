package sudoku;

import org.junit.jupiter.api.Test;

class SudokuSolverTest {

    @Test
    void solve() {
    }
}