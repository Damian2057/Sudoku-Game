package com.example.gui.resorc;

public class ResourcesEng extends java.util.ListResourceBundle {
    @Override
    public Object[][] getContents() {
        return new Object[][] {
                {"header", "Authors:"},
                {"a1", "Damian Biskupski"},
                {"a2", "Mateusz Dangreaux"},
        };
    }
}
