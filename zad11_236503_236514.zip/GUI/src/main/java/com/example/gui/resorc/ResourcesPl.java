package com.example.gui.resorc;

public class ResourcesPl extends java.util.ListResourceBundle {
    @Override
    public Object[][] getContents() {
        return new Object[][] {
                {"header", "Autorzy:"},
                {"a1", "Damian Biskupski"},
                {"a2", "Mateusz Dangreaux"},
        };
    }
}
